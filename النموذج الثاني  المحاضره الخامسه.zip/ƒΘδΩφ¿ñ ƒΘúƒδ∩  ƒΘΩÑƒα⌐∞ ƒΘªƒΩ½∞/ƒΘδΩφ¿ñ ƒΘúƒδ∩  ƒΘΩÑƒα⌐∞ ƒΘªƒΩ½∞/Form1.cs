﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace النموذج_الثاني__المحاضره_الخامسه
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            this.Left = 0;
            this.Width = this.Width + 100;
            this.Height = this.Height + 100;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button9.Width -= 5;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button9.Width += 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button9.Size = new Size(button9.Width, button9.Height + 5);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button9.Size = new Size(button9.Width, button9.Height - 5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.Top = button2.Top = button7.Top = button8.Top -= 2;
            button3.Top -= 2;
            button4.Top -= 2;
            button5.Top -= 2;
            button6.Top -= 2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Top = button2.Top = button7.Top = button8.Top += 2;
            button3.Top += 2;
            button4.Top += 2;
            button5.Top += 2;
            button6.Top += 2;
            //  button9.Location = new Point(button9.Left, button9.Top + 5);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button9.Left += 5;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button9.Left -= 5;
        }
    }
    }
//زر ^ و زر v لا يقومان بتحريك ال player وانما بتحريك جميع الازرار
