﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Width = 400;
            this.Height = 250;
            panel1.Visible = true;
            label5.Text = "-";
            panel1.BackColor = Color.BlueViolet;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Width = 400;
            this.Height = 250;
            panel1.Visible = true;
            label5.Text = "+";
            panel1.BackColor = Color.Green;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            double n1 = 0, n2 = 0;
            bool validInput = true;
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);
            }
            catch
            {
                MessageBox.Show("يرجاء ادخال صحيح للعدد الاول");
                textBox1.Focus();
                validInput = false; // علامة على أن الإدخال غير صحيح
            }
            try
            {
                n2 = Convert.ToDouble(textBox2.Text);
            }
            catch
            {
                MessageBox.Show(" يرجاء ادخال صحيح لعدد الثاني");
                textBox2.Focus();
                validInput = false;
            }
            if (validInput) // إذا كانت المدخلات صحيحة
            {
                if (label5.Text == "+")
                {
                    textBox3.Text = (n1 + n2).ToString();
                }
                else if (label5.Text == "-")
                {
                    textBox3.Text = (n1 - n2).ToString();
                }
                else if (label5.Text == "*")
                {
                    textBox3.Text = (n1 * n2).ToString();
                }
                else if (label5.Text == "/")
                { if (n2 == 0)
                    {
                        MessageBox.Show("لايمكن قسمه على صفر","تحذير");
                    }
                else
                    textBox3.Text = (n1 / n2).ToString();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Width = 400;
            this.Height = 250;
            panel1.Visible = true;
            label5.Text = "/";
            panel1.BackColor = Color.RosyBrown;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Width = 400;
            this.Height = 250;
            panel1.Visible = true;
            label5.Text = "*";
            panel1.BackColor = Color.Brown;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            this.Width = 400;
            this.Height = 90;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
